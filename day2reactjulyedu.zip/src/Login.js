class Trainee {
    name
    id
    phone

    attendTraining = (name)=>{
        this.name = name

        console.log("value of this operator is" , this)

        setTimeout(()=>{
            console.log("value of this operator is" , this)

        },3000)
    }
}

var  Murali  =new Trainee()
var  Sridhar  =new Trainee()
var  Ravikumar  =new Trainee()
var  Shruthi  =new Trainee()

Murali.attendTraining("Murali")
// Sridhar.attendTraining("Ari")
// Ravikumar.attendTraining("Ravi")
// Shruthi.attendTraining("Shruthi")

// value of this operator is lost

// expectation hurts 
// lets not keep the expectation

// name is a property 

// attendTraining() is a method  


// in javascript when we run functions that area is known as context of execution
// 

// settimeout inside we are calling a function

// inside timeout it will lose its scope to the timeout
// we dont want to loose we want to win // we used powerful function rather than normal function ()=>{} it is capable of preserving the scope where it is defined 
