import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar';
import Video from "./components/Video"
import MyCarousel from "./components/Carousel"
import videodata from "./video.json"
import Demo from './components/Statefulcomp';
import Signup from './components/Signup';

var video = {
  "name":"Friends",
  "image":"friends.jpeg"
}

function App() {
  let users = 0
  let parentfunction =  (data)=>{
    alert(data)
  }

  let joinMeeting = ()=>{
    users++
    console.log("users have joined meeting" , users)
  }
  return (
    <div className="App">
    <Navbar />
    <MyCarousel />
    <Signup />
    {/* <Demo prop1="Sridhar" /> */}

  {/* <div className="row">
    <Video fun={parentfunction} data={video} videojson={videodata} name="Friends" image="friends.jpeg" />
    <Video name="Family Man" image="familyman.jpeg" />
    <Video name="Big Bang theory " image="bigbangtheory.jpeg" />
    <Video name="Shaktiman" image="shaktiman.jpeg" />
  </div> */}

  

    </div>
  );
}

export default App;

// attributes passsed to a component are known as props
