import {Component} from "react"

 var vote

 var users = ["ashu" ,"Ram" , "Vineeth"]

 function validateEmail(email) {
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

 class Signup  extends Component{
   
    constructor(){
        super()
        alert("Constructor")
        this.state = {
            userslist:[]
        }
    }
    userlist = []
    user = {}
    handleEmail = (event)=>{
       this.user.email = event.target.value
    }
    handleName = (event)=>{
        this.user.name = event.target.value
     }
    handlePassword = (event)=>{
        this.user.password = event.target.value
     }

    signup = (event)=>{
        event.preventDefault()
       var result = validateEmail(this.user.email)
       if(result){
           this.setState({
               emailerror:false
           })
       }
       else{
           this.setState({
               emailerror:true
           })
       }
     console.log("user detsila" , this.user)
     var tempuser = {...this.user}
     this.userlist.push(tempuser)
     console.log("users who have registerd are" , this.userlist)
     this.setState({
         userslist:this.userlist
     })
    }

    render(){
        return (
            <div>


              <form>
                <input onChange={this.handleName}  placeholder="Name" className="form-control"></input>
                <input onChange={this.handleEmail} placeholder="Email" className="form-control"></input>
        {this.state.emailerror && <div className="errormessage"><label>Invalid Email</label></div> }
                <input onChange={this.handlePassword} type="password" placeholder="Password" className="form-control"></input>
                <button onClick={this.signup} className="btn btn-primary">Signup</button>

             </form>

                >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

               {this.state.userslist.length>0 && <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Handle</th>
    </tr>
  </thead>
  <tbody>
      {this.state.userslist.map((each,index)=>{

return  <tr key={index}>
<th scope="row">{index+1}</th>
      <td>{each.name}</td>
      <td>{each.email}</td>
      <td>{each.password}</td>


</tr>
      })}

   
   
   
  </tbody>
</table>}


            </div>
        )
    }
}

export default Signup


// onEventName = {functionname} not function call