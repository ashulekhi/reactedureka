import {Link} from "react-router-dom"
function Login(){
    return(
    <div style={{width:"50%" , margin:"auto"}}>
        <h1>Login Here</h1>
         <form>
            <div className="form-group">
            <label for="exampleInputEmail1">Email address</label>
            <input type="email" className="form-control"  aria-describedby="emailHelp"></input>
            <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small>
            </div>
            <div className="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input type="password" className="form-control"></input>
            </div>
            <div  className="from-group">
            <Link style={{float:"left"}} to="/signup">New User ? Click Here to Signup</Link>
            </div>
            <div className="form-group">
            <button style={{float:"right"}} type="submit" className="btn btn-primary">Login</button>
            </div>
            <div className="from-group">
            <Link style={{float:"right"}} to="/forgot">Forgot Password?</Link>
            </div>
       </form>
    </div>
       
    )
}

export default Login