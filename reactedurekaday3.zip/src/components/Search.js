function Search(){
    return(
        <div>
            <h1>Search Page</h1>
        </div>
    )
}

export default Search