function Pagenotfound(){
    return(
        <div style={{marginTop:"50px"}} className="container">
            <img style={{width:"100%"}} src="404.png"></img>
        </div>
    )
}

export default Pagenotfound