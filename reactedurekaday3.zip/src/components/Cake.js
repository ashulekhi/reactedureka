import {Link} from "react-router-dom"
function Cake(props){
    return (
       <div class="card col-3" style={{width: "16rem"}}>
            <Link to={`/cake/${props.data}`}>
             <img style={{height: "16rem"}} src={props.data.image} class="card-img-top" alt="..." />
             <div class="card-body">
                    <h5 class="card-title">{props.data.name}</h5>
                    <p class="card-text">{props.data.price}</p>
            </div>
            </Link>
        </div>
    )
}

export default Cake