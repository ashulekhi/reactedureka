import {Link} from "react-router-dom"

function Navbar(){

  return(
    <div>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
<Link to="/" class="navbar-brand">Ashu's Cake Gallery</Link>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav mr-auto">
<form style={{marginLeft:"50px"}} class="form-inline my-2 my-lg-0">
<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" />
<Link to="/search"><button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button></Link>
</form>
</ul>



<form class="form-inline my-2 my-lg-0">
 <Link to="/login"><button class="btn btn-primary my-2 my-sm-0" type="submit">Login</button></Link>
 <Link style={{marginLeft:"50px"}} to="/cart"><button class="btn btn-warning my-2 my-sm-0" type="submit">Cart</button></Link>
 
</form>
</div>
</nav>
</div>
  )
}

export default Navbar