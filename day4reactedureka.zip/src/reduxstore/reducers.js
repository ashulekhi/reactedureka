export function MainReducer(state={
    cartitems:[]
}, action){
    console.log("this action hase come " , action)
    switch(action.type){
        case "LOGIN" :{
            state = {...state}
            state["isuserloggedin"]=true
            return state
        }
        case "ADDTOCART" :{
            state = {...state}
            state["cartitems"].push(action.payload)
            return state
        }
        case "REMOVEFROMCART" :{
            state = {...state}
            state["cartitems"].splice(action.payload,1)
            return state
        }
        default : return state
    }
}