import {createStore} from "redux"
import {MainReducer} from "./reducers"

var store = createStore(MainReducer)

export default store









// var storedata = store.getState()

// console.log("store data is" , storedata)



// var storedata = store.getState()

// console.log("store data after actula dispatch is" , storedata)



// console.log("state after logout is" , store.getState())