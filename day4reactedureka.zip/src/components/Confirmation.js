function Confirmation(){
    return(
        <div>
            <h1>Confirmation Page</h1>
        </div>
    )
}

export default Confirmation