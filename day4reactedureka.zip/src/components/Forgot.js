function Forgot(){
    return(
        <div>
            <h1>Forgot Page</h1>
        </div>
    )
}

export default Forgot