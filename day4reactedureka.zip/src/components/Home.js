import {Component} from "react"
import Carousel from "./Carousel";
import Cake from "./Cake";
import axios from "axios"

class Home extends Component{
    constructor(){
        super()
        this.state = {
            cakes:[]
        }
    }

    componentDidMount(){
        let apiurl = "https://apifromashu.herokuapp.com/api/allcakes"
       
        axios({
            method:"GET",
            url:apiurl
        }).then((response)=>{
            console.log("Response from all cakes api" , response.data)
            this.setState({
                cakes:response.data.data
            })
        },(error)=>{
            console.log("error from all cakes api" , error)
        })
    }

    render(){
        return(
            <div>
                <Carousel />
                <div style={{marginTop:"2rem"}} className="row">
                    {this.state.cakes.map((each,index)=>{
                        return <Cake key={index} data={each} />
                    })}
                </div>
            </div>
        )
    }
}

export default Home

//{name,price,image,cakeid}