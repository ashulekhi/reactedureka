function Cakedetails(props){
    return(
        <div>
<h1>Cakedetails for {props.match.params.cakeid}</h1>
<h1>Cakedetails for {props.match.params.something}</h1>

        </div>
    )
}

export default Cakedetails