function Payment(){
    return(
        <div>
            <h1>Payment Page</h1>
        </div>
    )
}

export default Payment