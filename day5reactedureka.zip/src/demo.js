var training = "react"
if(training=="react"){

    let trainer = "Ashu Lekhi"
    var x = 10
    var y = {}
    var z = function(){}
    const friends = ["vineeth" , "sridhar"]
    var isSuperman = true
    const gangadharisshaktiman = false

    // gangadharisshaktiman = true







}

